<?php
	require_once('courseTest.php');
	require_once('golfUtilTest.php');
	require_once('scorecardTest.php');
?>
